//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    vehiculo V1= new vehiculo("LLL 343", "BMW", 1987, 200, 300,3200, true);


}