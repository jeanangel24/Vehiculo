public class vehiculo {
    private String placa;
    private String marca;
    private int modelo;
    private double kilometrosrecorridos;
    private double litrosconsumidos;
    private double preciolitro;
    private boolean activo;

    public vehiculo() {
    }

    public vehiculo(String placa, String marca, int modelo, double kilometrosrecorridos, double litrosconsumidos, double preciolitro, boolean activo) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.kilometrosrecorridos = kilometrosrecorridos;
        this.litrosconsumidos = litrosconsumidos;
        this.preciolitro = preciolitro;
        this.activo = activo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getModelo() {
        return modelo;
    }

    public void setModelo(int modelo) {
        this.modelo = modelo;
    }

    public double getKilometrosrecorridos() {
        return kilometrosrecorridos;
    }

    public void setKilometrosrecorridos(double kilometrosrecorridos) {
        this.kilometrosrecorridos = kilometrosrecorridos;
    }

    public double getLitrosconsumidos() {
        return litrosconsumidos;
    }

    public void setLitrosconsumidos(double litrosconsumidos) {
        this.litrosconsumidos = litrosconsumidos;
    }

    public double getPreciolitro() {
        return preciolitro;
    }

    public void setPreciolitro(double preciolitro) {
        this.preciolitro = preciolitro;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    @Override
    public String toString() {
        return "vehiculo{" +
                "placa='" + placa + '\'' +
                ", marca='" + marca + '\'' +
                ", modelo=" + modelo +
                ", kilometrosrecorridos=" + kilometrosrecorridos +
                ", litrosconsumidos=" + litrosconsumidos +
                ", preciolitro=" + preciolitro +
                ", activo=" + activo +
                ",rendimiento=" + calcularrendimiento() +
                ",clasificacion=" + clasificarrendimiento() +
                ", costo combustible" + calcularcostocombustible() +
                " costo kilometero" + costoporkilometro() +
                " recomendacion" + generarrecomendacion() +
                '}';
    }

    //METODOS PROPIOS//
    public double calcularrendimiento() {
        return (this.kilometrosrecorridos / litrosconsumidos);
    }

    public String clasificarrendimiento() {
        double consumo = calcularrendimiento();
        if (consumo < 8) {

            return "Consumo alto";

        } else if (consumo < 12) {
            return "Consumo moderado";
        } else if (consumo < 16) {
            return "Consumo eficiente";
        } else if (consumo >= 16) {
            return "Consumo muy eficiente";
        }
    }

    public double calcularcostocombustible() {
        return (this.litrosconsumidos * preciolitro);
    }

    public double costoporkilometro() {
        double costo = kilometrosrecorridos;
        return (this.calcularcostocombustible() / kilometrosrecorridos);

    }

    public boolean actualizarkilometraje(double nuevoskilometros) {
        double kilometraje = kilometrosrecorridos;
        if (kilometraje > 0) {
            return true;
        } else {
            return false;
        }
    }

    public String generarrecomendacion() {
        String clasificar = clasificarrendimiento();
        if (clasificar.equalsIgnoreCase("consumo alto")) {
            return "revisar motor y sistema de conbustible";
        }
        else if (clasificar.equalsIgnoreCase("consumo moderado")){
            return "revisar habitos de conduccion";
        }
        else if (clasificar.equalsIgnoreCase("consumo eficiente")){
            return "el vehiculo presenta buen rendimiento";
        }else if (clasificar.equalsIgnoreCase("consumo muy eficiente")){
            return "Excelente rendimiento";
        }

    }
}


