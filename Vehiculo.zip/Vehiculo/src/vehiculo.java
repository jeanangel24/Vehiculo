public class vehiculo {
    private String placa;
    private String marca;
    private int modelo;
    private double kilometrosrecorridos;
    private double litrosconsumidos;
    private double preciolitro;
    private boolean activo;

    public vehiculo() {
    }

    public vehiculo(String placa, String marca, int modelo, double kilometrosrecorridos, double litrosconsumidos, double preciolitro, boolean activo) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.kilometrosrecorridos = kilometrosrecorridos;
        this.litrosconsumidos = litrosconsumidos;
        this.preciolitro = preciolitro;
        this.activo = activo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getModelo() {
        return modelo;
    }

    public void setModelo(int modelo) {
        this.modelo = modelo;
    }

    public double getKilometrosrecorridos() {
        return kilometrosrecorridos;
    }

    public void setKilometrosrecorridos(double kilometrosrecorridos) {
        this.kilometrosrecorridos = kilometrosrecorridos;
    }

    public double getLitrosconsumidos() {
        return litrosconsumidos;
    }

    public void setLitrosconsumidos(double litrosconsumidos) {
        this.litrosconsumidos = litrosconsumidos;
    }

    public double getPreciolitro() {
        return preciolitro;
    }

    public void setPreciolitro(double preciolitro) {
        this.preciolitro = preciolitro;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
}
